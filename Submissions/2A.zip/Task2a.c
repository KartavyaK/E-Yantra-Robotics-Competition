/*
*
*   ===================================================
*       CropDrop Bot (CB) Theme [eYRC 2025-26]
*   ===================================================
*
*  This script is intended to be an Boilerplate for 
*  Task 2a of CropDrop Bot (CB) Theme [eYRC 2025-26].
*
*  Filename:		Task2a.c
*  Created:		    19/08/2025
*  Last Modified:	12/09/2025
*  Author:		    Team members Name
*  Team ID:		    [ CB_xxxx ]
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*  
*  e-Yantra - An MHRD project under National Mission on Education using ICT (NMEICT)
*
**********************************************

*/
// Platform-specific includes for Windows compatibility
#ifdef _WIN32
    #define WINVER 0x0600
    #define _WIN32_WINNT 0x0600
    #include <winsock2.h>
    #include <ws2tcpip.h>
#endif

#include "coppeliasim_client.h"  // Include our header
#include <sys/time.h>
#include <math.h>
#include <string.h>

// Global client instance for socket communication
SocketClient client;

// ----------------------
// Forward declarations
// ----------------------
void* control_loop(void* arg);

/**
 * @brief Establishes connection to the CoppeliaSim server
 */
int connect_to_server(SocketClient* c, const char* ip, int port) {
#ifdef _WIN32
    // Initialize Winsock on Windows
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("WSAStartup failed\n");
        return 0;
    }
#endif
    
    // Create TCP socket
    c->sock = socket(AF_INET, SOCK_STREAM, 0);
    if (c->sock < 0) {
        printf("Socket creation failed\n");
        return 0;
    }

    // Setup server address structure
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    inet_pton(AF_INET, ip, &serv_addr.sin_addr);

    // Attempt to connect to server
    if (connect(c->sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("Connection failed\n");
        CLOSESOCKET(c->sock);
#ifdef _WIN32
        WSACleanup();
#endif
        return 0;
    }

    c->running = true;

    // Start the receive thread to handle incoming sensor data
#ifdef _WIN32
    c->recv_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)receive_loop, c, 0, NULL);
#else
    pthread_create(&c->recv_thread, NULL, receive_loop, c);
#endif

    return 1;
}

/**
 * @brief Get current time in seconds
 */
double get_current_time() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + tv.tv_usec / 1000000.0;
}


/**
 * @brief Main control loop thread for robot behavior
 */
void* control_loop(void* arg) {
    SocketClient* c = (SocketClient*)arg;
    int node_count = 0;
    
    
    while (c->running) {
    // ========================================
    // LINE FOLLOWING SENSORS (IR SENSORS)
    // ========================================
    // These sensors detect black lines on white surface
    // Values typically range from 0.0 to 1.0
    // Lower values indicate darker surface (line detected)
    // Higher values indicate lighter surface (no line)
    float ir1 = c->line_sensors[0];  // left_corner sensor
    float ir2 = c->line_sensors[1];  // left sensor
    float ir3 = c->line_sensors[2];  // middle sensor (center)
    float ir4 = c->line_sensors[3];  // right sensor
    float ir5 = c->line_sensors[4];  // right_corner sensor
    // printf("Line sensor readings: [%.2f, %.2f, %.2f, %.2f, %.2f]\n", ir1, ir2, ir3, ir4, ir5);

    // ========================================
    // PROXIMITY SENSOR (ULTRASONIC/DISTANCE)
    // ========================================
    float proximity = c->proximity_distance;
    printf("Proximity sensor distance: %.1f meters\n", proximity);

    // ========================================
    // COLOR SENSOR (RGB VALUES)
    // ========================================
    float red = c->color_r;
    float green = c->color_g;
    float blue = c->color_b;
    int colour;
    printf("Color RGB raw values: (%.3f, %.3f, %.3f)\n", red, green, blue);
    SLEEP(50);

    // ========================================
    // ACTUATOR COMMANDS
    // ========================================
    float list[5] = {ir1, ir2, ir3, ir4, ir5};
    int ir_data[5];
    double pos_count = 0;
    int box = 0;

    // Threshold conversion (assuming 0 = white, 1 = black line)
    for (int i = 0; i < 5; i++) {
        if (list[i] > 0.5)
            ir_data[i] = 0;
        else
            ir_data[i] = 1;
    }

    printf("IR data: ");
    for (int i = 0; i < 5; i++) {
        printf("%d ", ir_data[i]);
    }
    printf("\n");

    // ---------- PID LINE FOLLOWING LOGIC ----------
    int sensor_count = 0;
    float weights[5] = {-2, -1, 0, 1, 2};
    float sum_val = 0, sum_weight = 0;
    float line_pos = 0;
    float error = 0, lasterror = 0, integral = 0, derivative = 0;
    float proportional, output;
    float Kp = 0.3, Ki = 0.00001, Kd = 0.4;
    float base_speed = 3;
    float left_speed, right_speed;

    // --- Compute weighted line position ---
    for (int i = 0; i < 5; i++) {
        sum_val += ir_data[i];
        sum_weight += ir_data[i] * weights[i];
    }

    // Avoid divide-by-zero
    if (sum_val > 0)
        line_pos = sum_weight / sum_val;
    else
        line_pos = 0;  // Line lost — fallback center

    // --- PID control ---
    error = -line_pos;
    proportional = error;
    integral += error;
    derivative = error - lasterror;

    output = (Kp * proportional) + (Ki * integral) + (Kd * derivative);
    lasterror = error;

    if (node_count <= 10){
    // --- Motor control ---
    left_speed = base_speed - output;
    right_speed = base_speed + output;
    set_motor(c, left_speed, right_speed);
    }

    if (proximity < 0.5) {
        pick_box(c);
        left_speed = 0;
        right_speed = 0;
        set_motor(c, left_speed, right_speed);
        box = 1;

        // RED
        if (red != 0 && green != 0 && blue == 0) {
            printf("Red found \n");
            colour = 1;
        }
        // GREEN
        else if (red != 0 && green == 0 && blue != 0) {
            printf("Green found \n");
            colour = 2;
        }
        // BLUE
        else if (red != 0 && green == 0 && blue == 0) {
            printf("Blue found \n");
            colour = 3;
        }
        else {
            printf("No colour detected\n");
        }
    }
    
    

    for (int i = 0; i < 5; i++){
        if (ir_data[i]==1){
            sensor_count +=1;
        }
    }

    // Deciding the path
    if (sensor_count > 3) {
        node_count += 1;
        if (node_count < 10){
        if (colour == 1) {
            left_speed = -(0.8 * left_speed);
            right_speed = (1.5 * right_speed);
            set_motor(c, left_speed, right_speed);

        }
        else if (colour == 2) {
            left_speed = (1.5 * left_speed);
            right_speed = -(0.8 * right_speed);
            set_motor(c, left_speed, right_speed);
        }
        else if (colour == 3) {
            left_speed = left_speed;
            right_speed = right_speed;
            set_motor(c, left_speed, right_speed);
        }
        else {
            printf("Cannot decide path \n");
        }
    }
        if ((colour == 1)||(colour == 2)){
            if (node_count >= 10){
            left_speed = 0;
            right_speed = 0;
            set_motor(c, left_speed, right_speed);
            drop_box(c);
            box = 0;
            }
        }
        else if (colour == 3){
            if(node_count >= 8){
                left_speed = 0;
                right_speed = 0;
                set_motor(c, left_speed, right_speed);
                drop_box(c);
                box = 0;
            }
        }
    }

    // if ((ir_data[0] == 0 && ir_data[1] == 1 && ir_data[2] == 1 && ir_data[3] == 1 && ir_data[4] == 0) && box == 1) {
    //     left_speed = 0;
    //     right_speed = 0;
    //     set_motor(c, left_speed, right_speed);
    //     drop_box(c);
    //     box = 0;
    // }

    // set_motor(c, left_speed, right_speed);
    // printf("Left motor speed: %.3f \n", left_speed);
    // printf("Right motor speed: %.3f \n", right_speed);
    // printf("Output: %.3f \n", output);
    printf("Node_count: %d \n", node_count);

    SLEEP(50);  // Wait 5ms before next iteration
}

return NULL;
}

/**
 * @brief Main function - Entry point of the program
 */
int main() {
    // Attempt to connect to CoppeliaSim server
    if (!connect_to_server(&client, "127.0.0.1", 50002)) {
        printf("Failed to connect to CoppeliaSim server. Make sure:\n");
        printf("1. CoppeliaSim is running\n");
        printf("2. The simulation scene is loaded\n");
        printf("3. The ZMQ remote API is enabled on port 50002\n");
        return -1;
    }
    
    printf("Successfully connected to CoppeliaSim server!\n");
    printf("Starting control thread...\n");
    
    // Start the control thread for robot behavior
#ifdef _WIN32
    HANDLE control_thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)control_loop, &client, 0, NULL);
#else
    pthread_t control_thread;
    pthread_create(&control_thread, NULL, control_loop, &client);
#endif

    // Main loop: Display sensor data continuously
    printf("Monitoring sensor data... (Press Ctrl+C to exit)\n");
    while (1) {
        SLEEP(100);  // Update display every 100ms
    }

    // Cleanup
    printf("Disconnecting...\n");
    disconnect(&client);
    return 0;
}





















































